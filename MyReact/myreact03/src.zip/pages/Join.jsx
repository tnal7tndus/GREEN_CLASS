//import React, { useState, useEffect } from 'react';
//import '../../styles/Join.scss';
//import { useNavigate } from 'react-router-dom';

function Join() {
   
    return (
        <>
            <div id="join_container">
                <p className="pageTitle">회원가입</p>
                <div id="contents">
                    <div className="joinbox">
                        <p>약관 동의</p>
                        <form>
                            
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Join;
